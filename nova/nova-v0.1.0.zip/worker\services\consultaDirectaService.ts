import { responderConsultaHistorial } from "./consultaHistorialService.js";

type EntidadValor = {
  entidad_id: number;
  nombre_base: string;
  valor: string;
};

const ALIAS: Record<string, string> = {
  bicis: "bicicleta",
  bici: "bicicleta",
  bicicletas: "bicicleta",
  bicicleta: "bicicleta",
  carros: "carro",
  carro: "carro",
  motos: "moto",
  moto: "moto",
  mascotas: "mascota",
  mascota: "mascota",
};

const NUMEROS = [
  "cero",
  "una",
  "dos",
  "tres",
  "cuatro",
  "cinco",
  "seis",
  "siete",
  "ocho",
  "nueve",
  "diez",
];

function normalizar(texto: string) {
  return texto
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[¿?¡!.,;:]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function numeroTexto(numero: number) {
  return NUMEROS[numero] ?? String(numero);
}

function pluralizar(nombre: string) {
  if (nombre.endsWith("s")) {
    return nombre;
  }

  if (/[aeiou]$/.test(nombre)) {
    return `${nombre}s`;
  }

  return `${nombre}es`;
}

function obtenerEntidadPregunta(texto: string) {
  const palabras = normalizar(texto).split(" ").reverse();

  for (const palabra of palabras) {
    if (ALIAS[palabra]) {
      return ALIAS[palabra];
    }
  }

  return null;
}

async function contarEntidades(db: D1Database, entidad: string) {
  const resultado = await db
    .prepare(
      `
      SELECT COUNT(*) AS cantidad
      FROM entidades
      WHERE estado = 'activa'
        AND LOWER(nombre_base) = LOWER(?)
    `,
    )
    .bind(entidad)
    .first<{
      cantidad: number;
    }>();

  return Number(resultado?.cantidad ?? 0);
}

async function obtenerValoresActuales(
  db: D1Database,
  entidad: string,
  clave: string,
) {
  const resultado = await db
    .prepare(
      `
      SELECT
        e.id AS entidad_id,
        e.nombre_base,
        m.valor
      FROM entidades e
      INNER JOIN memorias m
        ON m.entidad_id = e.id
      WHERE e.estado = 'activa'
        AND m.estado = 'activa'
        AND LOWER(e.nombre_base) = LOWER(?)
        AND LOWER(m.clave) = LOWER(?)
      ORDER BY e.id ASC
    `,
    )
    .bind(entidad, clave)
    .all<EntidadValor>();

  return resultado.results;
}

function unirValores(valores: string[]) {
  if (valores.length === 1) {
    return valores[0];
  }

  return `${valores.slice(0, -1).join(", ")} y ${valores.at(-1)}`;
}

async function responderCantidad(db: D1Database, mensaje: string) {
  const texto = normalizar(mensaje);

  if (!texto.startsWith("cuantas ") && !texto.startsWith("cuantos ")) {
    return null;
  }

  const entidad = obtenerEntidadPregunta(texto);

  if (!entidad) {
    return null;
  }

  const cantidad = await contarEntidades(db, entidad);

  if (cantidad === 0) {
    return null;
  }

  return `Tienes ${numeroTexto(cantidad)} ${pluralizar(entidad)}.`;
}

async function responderColor(db: D1Database, mensaje: string) {
  const texto = normalizar(mensaje);

  if (!texto.includes("color") || !texto.includes("mis ")) {
    return null;
  }

  const entidad = obtenerEntidadPregunta(texto);

  if (!entidad) {
    return null;
  }

  const cantidad = await contarEntidades(db, entidad);

  const memorias = await obtenerValoresActuales(db, entidad, "color");

  if (cantidad === 0 || memorias.length !== cantidad) {
    return null;
  }

  const colores = memorias.map((memoria) => memoria.valor);

  if (cantidad === 1) {
    return `Tu ${entidad} es ${colores[0]}.`;
  }

  if (cantidad === 2) {
    return `Tienes dos ${pluralizar(entidad)}: una ${colores[0]} y otra ${colores[1]}.`;
  }

  return `Tienes ${numeroTexto(cantidad)} ${pluralizar(entidad)}. Sus colores actuales son ${unirValores(colores)}.`;
}

export async function responderConsultaDirecta(
  db: D1Database,
  mensaje: string,
) {
  if (!mensaje.includes("?") && !mensaje.includes("¿")) {
    return null;
  }

  return (
    (await responderConsultaHistorial(db, mensaje)) ??
    (await responderCantidad(db, mensaje)) ??
    (await responderColor(db, mensaje))
  );
}
