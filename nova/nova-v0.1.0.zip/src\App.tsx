// ======================================================
// NOVA - COMPONENTE PRINCIPAL
// ======================================================

// Importamos los estilos principales de la aplicación.
import "./App.css";
import Chat from "./features/chat/components/Chat";
// ======================================================
// APP
// ======================================================
// Este es el componente principal de NOVA.
//
// Su trabajo NO será contener toda la aplicación.
// Más adelante simplemente conectará los diferentes
// módulos que vayamos creando.
// ======================================================

function App() {
  return (
    <main>
      <h1>NOVA</h1>

      <p>Tu inteligencia artificial personal.</p>

      <Chat />
    </main>
  );
}
export default App;
