import { useEffect, useState } from "react";
import {
  obtenerUsoIA,
  type UsoIA,
} from "../services/usoIaService";
import "../styles/UsoIa.css";

type UsoIaProps = {
  actualizacion: number;
};

function formatearNumero(valor: number) {
  return new Intl.NumberFormat("es-CO", {
    maximumFractionDigits: 1,
  }).format(valor);
}

function UsoIa({ actualizacion }: UsoIaProps) {
  const [uso, setUso] = useState<UsoIA | null>(null);

  useEffect(() => {
    async function cargarUso() {
      try {
        const datos = await obtenerUsoIA();
        setUso(datos);
      } catch (error) {
        console.error(
          "[NOVA] Error obteniendo uso de IA:",
          error,
        );
      }
    }

    cargarUso();
  }, [actualizacion]);

  if (!uso) {
    return (
      <div className="uso-ia">
        <span>⚡ Calculando uso...</span>
      </div>
    );
  }

  const porcentaje = Math.max(
    0,
    Math.min(100, uso.porcentajeRestante),
  );

  return (
    <section className="uso-ia">
      <div className="uso-ia__cabecera">
        <div>
          <span className="uso-ia__titulo">
            ⚡ Neurons disponibles
          </span>

          <strong className="uso-ia__numero">
            {formatearNumero(
              uso.neuronsRestantes,
            )}{" "}
            /{" "}
            {formatearNumero(
              uso.limiteDiario,
            )}
          </strong>
        </div>

        <span className="uso-ia__porcentaje">
          {formatearNumero(porcentaje)}%
        </span>
      </div>

      <div className="uso-ia__barra">
        <div
          className="uso-ia__progreso"
          style={{
            width: `${porcentaje}%`,
          }}
        />
      </div>

      <div className="uso-ia__detalle">
        <span>
          Usadas:{" "}
          {formatearNumero(
            uso.neuronsUsadas,
          )}
        </span>

        <span>
          Llamadas: {uso.llamadas}
        </span>
      </div>
    </section>
  );
}

export default UsoIa;