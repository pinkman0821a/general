import { INSTRUCCIONES_NOVA } from "../prompts/novaPrompt.js";
import {
  prepararEventosMemoria,
  type EventoMemoria,
} from "./eventoMemoriaService.js";
import type { Memoria } from "./memoriaService.js";
import {
  crearRespuestaEvento,
  crearStreamRespuesta,
} from "./respuestaEventoService.js";
import { contabilizarStream } from "./streamUsoService.js";
import { registrarUsoIA } from "./usoIaService.js";

const MODELO_NOVA = "@cf/meta/llama-3.1-8b-instruct-fp8";

export type MensajeConversacion = {
  autor: "usuario" | "nova";
  texto: string;
};

export type ContextoSistema = {
  fechaHoraLocal: string;
  fechaHoraUtc: string;
  zonaHoraria: string;
};

function crearEtiquetasEntidades(
  memoriasActivas: Memoria[],
  historialMemorias: Memoria[],
) {
  const ids = [
    ...new Set(
      [...memoriasActivas, ...historialMemorias]
        .map((memoria) => memoria.entidad_id)
        .filter((id): id is number => typeof id === "number"),
    ),
  ].sort((a, b) => a - b);

  const etiquetas = new Map<number, string>();

  ids.forEach((id, indice) => {
    etiquetas.set(id, `Entidad ${String.fromCharCode(65 + indice)}`);
  });

  return etiquetas;
}

function prepararMemorias(memorias: Memoria[], etiquetas: Map<number, string>) {
  if (memorias.length === 0) {
    return "Ninguna.";
  }

  const grupos = new Map<
    string,
    {
      titulo: string;
      memorias: Memoria[];
    }
  >();

  for (const memoria of memorias) {
    const tieneEntidadId = typeof memoria.entidad_id === "number";

    const claveGrupo = tieneEntidadId
      ? `id:${memoria.entidad_id}`
      : `sin-id:${memoria.tipo}:${memoria.entidad ?? "Juan"}`;

    if (!grupos.has(claveGrupo)) {
      const nombre = memoria.entidad?.trim() || "Juan";

      const etiqueta = tieneEntidadId
        ? etiquetas.get(memoria.entidad_id!)
        : null;

      grupos.set(claveGrupo, {
        titulo: etiqueta ? `[${etiqueta}] ${nombre}` : nombre,
        memorias: [],
      });
    }

    grupos.get(claveGrupo)!.memorias.push(memoria);
  }

  return [...grupos.values()]
    .map((grupo) => {
      const datos = grupo.memorias
        .map((memoria) => `  - ${memoria.clave} = ${memoria.valor}`)
        .join("\n");

      return `${grupo.titulo}\n${datos}`;
    })
    .join("\n\n");
}

function prepararMensajes(
  mensajes: MensajeConversacion[],
  contextoSistema: ContextoSistema,
  memoriasActivas: Memoria[],
  historialMemorias: Memoria[],
  eventosMemoria: EventoMemoria[],
) {
  const etiquetas = crearEtiquetasEntidades(memoriasActivas, historialMemorias);

  const instruccionesSistema = `
${INSTRUCCIONES_NOVA}

CONTEXTO ACTUAL:

Fecha y hora local:
${contextoSistema.fechaHoraLocal}

Zona horaria:
${contextoSistema.zonaHoraria}

Fecha y hora UTC:
${contextoSistema.fechaHoraUtc}

CAMBIOS CONFIRMADOS EN ESTE MENSAJE:

${prepararEventosMemoria(eventosMemoria)}

RECUERDOS ACTUALES:

${prepararMemorias(memoriasActivas, etiquetas)}

RECUERDOS ANTERIORES:

${prepararMemorias(historialMemorias, etiquetas)}

REGLAS DE MEMORIA:

Los cambios confirmados son hechos ya resueltos por el sistema.

Usa los recuerdos actuales para hablar del presente.

Usa los recuerdos anteriores solamente cuando Juan pregunte por el pasado.

Cuando existan varias entidades con el mismo nombre base, trátalas como entidades diferentes.

Las etiquetas internas existen únicamente para distinguir entidades.

Nunca menciones etiquetas internas, IDs, estructura, base de datos o forma de almacenamiento.

Nunca digas "según mis recuerdos", "según mi base de datos" o similares.

Nunca inventes información personal.

Si no conoces un dato, dilo directamente.

REGLAS TEMPORALES:

La fecha y hora del contexto actual son la fuente de verdad.

Nunca inventes fechas u horas.

REGLAS DE UBICACIÓN:

La zona horaria no demuestra la ubicación física de Juan.
`.trim();

  return [
    {
      role: "system" as const,
      content: instruccionesSistema,
    },
    ...mensajes.map((mensaje) => ({
      role:
        mensaje.autor === "usuario"
          ? ("user" as const)
          : ("assistant" as const),
      content: mensaje.texto,
    })),
  ];
}

function obtenerUltimoUsuario(mensajes: MensajeConversacion[]) {
  return (
    [...mensajes].reverse().find((mensaje) => mensaje.autor === "usuario")
      ?.texto ?? ""
  );
}

export async function generarRespuestaNova(
  ai: Ai,
  mensajes: MensajeConversacion[],
  contextoSistema: ContextoSistema,
  memoriasActivas: Memoria[],
  historialMemorias: Memoria[],
  eventosMemoria: EventoMemoria[] = [],
  db?: D1Database,
) {
  const respuestaDirecta = crearRespuestaEvento(
    eventosMemoria,
    obtenerUltimoUsuario(mensajes),
  );

  if (respuestaDirecta) {
    return respuestaDirecta;
  }

  const respuesta = await ai.run(MODELO_NOVA, {
    messages: prepararMensajes(
      mensajes,
      contextoSistema,
      memoriasActivas,
      historialMemorias,
      eventosMemoria,
    ),
  });

  if (db && respuesta.usage) {
    await registrarUsoIA(db, respuesta.usage);
  }

  const contenido = respuesta.response;

  if (typeof contenido !== "string" || contenido.trim() === "") {
    throw new Error("La IA no devolvió una respuesta de texto");
  }

  return contenido;
}

export async function generarRespuestaNovaStream(
  ai: Ai,
  mensajes: MensajeConversacion[],
  contextoSistema: ContextoSistema,
  memoriasActivas: Memoria[],
  historialMemorias: Memoria[],
  eventosMemoria: EventoMemoria[] = [],
  db?: D1Database,
) {
  const respuestaDirecta = crearRespuestaEvento(
    eventosMemoria,
    obtenerUltimoUsuario(mensajes),
  );

  if (respuestaDirecta) {
    return crearStreamRespuesta(respuestaDirecta);
  }

  const stream = await ai.run(MODELO_NOVA, {
    messages: prepararMensajes(
      mensajes,
      contextoSistema,
      memoriasActivas,
      historialMemorias,
      eventosMemoria,
    ),
    stream: true,
  });

  if (!db) {
    return stream;
  }

  return contabilizarStream(stream as ReadableStream<Uint8Array>, db);
}
