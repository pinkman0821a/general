import type { MemoriaExtraida } from "./memoriaExtractor.js";

export type ResultadoMemoriaRapida = {
  memorias: MemoriaExtraida[];
  usarIA: boolean;
};

const COLORES = [
  "amarilla",
  "amarillo",
  "plateada",
  "plateado",
  "morada",
  "morado",
  "purpura",
  "violeta",
  "rosada",
  "rosado",
  "blanca",
  "blanco",
  "negra",
  "negro",
  "verde",
  "roja",
  "rojo",
  "azul",
  "gris",
  "cafe",
  "marron",
  "rosa",
  "naranja",
  "beige",
  "dorada",
  "dorado",
];

const MENSAJES_IGNORABLES = new Set([
  "hola",
  "hola nova",
  "buenas",
  "buenos dias",
  "buenas tardes",
  "buenas noches",
  "gracias",
  "muchas gracias",
  "ok",
  "okay",
  "listo",
  "vale",
  "ya",
  "jaja",
  "jajaja",
  "jeje",
  "jsjs",
  "jsjsjs",
]);

function normalizar(texto: string) {
  return texto
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[¿?¡!.,;:]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function escaparRegex(texto: string) {
  return texto.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function regexColores() {
  return COLORES.map(escaparRegex).join("|");
}

function esMensajeIgnorable(mensaje: string) {
  return MENSAJES_IGNORABLES.has(normalizar(mensaje));
}

function esPregunta(mensaje: string) {
  return mensaje.includes("?") || mensaje.includes("¿");
}

function crearMemoriaColor(
  entidad: string,
  referencia: string | null,
  valor: string,
): MemoriaExtraida {
  return {
    tipo: "objeto",
    entidad: entidad.trim(),
    referencia,
    clave: "color",
    valor,
    confianza: 1,
    importancia: 6,
  };
}

function extraerCambioColorConReferencia(mensaje: string) {
  const texto = normalizar(mensaje);
  const colores = regexColores();

  const patron = new RegExp(
    `^(?:mi|el|la)\\s+(.+?)\\s+(${colores})\\s+ahora\\s+(?:es|esta)\\s+(${colores})$`,
  );

  const resultado = texto.match(patron);

  if (!resultado) {
    return null;
  }

  return crearMemoriaColor(resultado[1], resultado[2], resultado[3]);
}

function extraerCambioColorSinReferencia(mensaje: string) {
  const texto = normalizar(mensaje);
  const colores = regexColores();

  const patron = new RegExp(
    `^(?:mi|el|la)\\s+(.+?)\\s+ahora\\s+(?:es|esta)\\s+(${colores})$`,
  );

  const resultado = texto.match(patron);

  if (!resultado) {
    return null;
  }

  return crearMemoriaColor(resultado[1], null, resultado[2]);
}

function extraerEntidadNuevaColor(mensaje: string) {
  const texto = normalizar(mensaje);
  const colores = regexColores();

  const patron = new RegExp(
    `^tengo\\s+(?:otra|otro|una nueva|un nuevo)\\s+(.+?)\\s+(${colores})$`,
  );

  const resultado = texto.match(patron);

  if (!resultado) {
    return null;
  }

  return crearMemoriaColor(resultado[1], null, resultado[2]);
}

function extraerColorSimple(mensaje: string) {
  const texto = normalizar(mensaje);
  const colores = regexColores();

  const patron = new RegExp(
    `^(?:mi|el|la)\\s+(.+?)\\s+(?:es|esta)\\s+(${colores})$`,
  );

  const resultado = texto.match(patron);

  if (!resultado) {
    return null;
  }

  const entidad = resultado[1].trim();

  if (entidad.endsWith(" ahora")) {
    return null;
  }

  return crearMemoriaColor(entidad, null, resultado[2]);
}

export function analizarMemoriaRapida(mensaje: string): ResultadoMemoriaRapida {
  if (esMensajeIgnorable(mensaje) || esPregunta(mensaje)) {
    return {
      memorias: [],
      usarIA: false,
    };
  }

  const memoria =
    extraerCambioColorConReferencia(mensaje) ??
    extraerCambioColorSinReferencia(mensaje) ??
    extraerEntidadNuevaColor(mensaje) ??
    extraerColorSimple(mensaje);

  if (memoria) {
    return {
      memorias: [memoria],
      usarIA: false,
    };
  }

  return {
    memorias: [],
    usarIA: true,
  };
}
