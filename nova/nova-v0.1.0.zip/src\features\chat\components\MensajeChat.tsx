import ReactMarkdown from "react-markdown";
import type { Mensaje } from "../types/Mensaje";
import "../styles/MensajeChat.css";

type MensajeChatProps = {
  mensaje: Mensaje;
};

function MensajeChat({ mensaje }: MensajeChatProps) {
  return (
    <article
      className={`mensaje-chat ${
        mensaje.autor === "nova"
          ? "mensaje-chat--nova"
          : "mensaje-chat--usuario"
      }`}
    >
      <strong>{mensaje.autor === "nova" ? "NOVA" : "Tú"}</strong>

      <ReactMarkdown>{mensaje.texto}</ReactMarkdown>
    </article>
  );
}

export default MensajeChat;
