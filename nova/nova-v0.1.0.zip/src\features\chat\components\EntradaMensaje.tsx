// ======================================================
// NOVA - ENTRADA DE MENSAJE
// ======================================================

// useState permite guardar información temporal
// dentro de un componente.
import { useState } from "react";
import "../styles/EntradaMensaje.css";
// ======================================================
// PROPS
// ======================================================

// EntradaMensaje recibirá una función desde Chat.
//
// Cuando el usuario presione "Enviar",
// utilizaremos esa función para entregar el texto
// al componente padre.

type EntradaMensajeProps = {
  onEnviar?: (texto: string) => void;
};
// ======================================================
// COMPONENTE
// ======================================================

function EntradaMensaje({ onEnviar }: EntradaMensajeProps) {
  // ----------------------------------------------------
  // TEXTO DEL MENSAJE
  // ----------------------------------------------------
  // "texto" contiene lo que el usuario está escribiendo.
  //
  // "setTexto" nos permite cambiar ese contenido.
  //
  // Empieza vacío porque usamos useState('').
  // ----------------------------------------------------
  const [texto, setTexto] = useState("");
  // ======================================================
  // ENVIAR MENSAJE
  // ======================================================
  // Esta función se ejecutará cuando el usuario
  // presione el botón "Enviar".
  //
  // Por ahora solamente limpiaremos la caja.
  // Después esta misma función enviará el mensaje
  // al componente Chat.
  // ======================================================
  function manejarEnvio() {
    // Quitamos espacios innecesarios del mensaje.
    const textoLimpio = texto.trim();

    // Si después de limpiar no queda texto,
    // no enviamos nada.
    if (textoLimpio === "") {
      return;
    }

    // Entregamos el mensaje al componente padre
    // si existe una función onEnviar.
    onEnviar?.(textoLimpio);

    // Limpiamos la caja después del envío.
    setTexto("");
  }
  return (
    <div className="entrada-mensaje">
      <input
        className="entrada-mensaje__input"
        type="text"
        placeholder="Escribe un mensaje..."
        value={texto}
        onChange={(evento) => setTexto(evento.target.value)}
        onKeyDown={(evento) => {
          if (evento.key === "Enter") {
            manejarEnvio();
          }
        }}
      />
      <button className="entrada-mensaje__boton" onClick={manejarEnvio}>
        {" "}
        Enviar
      </button>
    </div>
  );
}

export default EntradaMensaje;
