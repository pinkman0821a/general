// ======================================================
// NOVA - LISTA DE MENSAJES
// ======================================================

// Importamos la estructura que debe tener
// cada mensaje.
import type { Mensaje } from "../types/Mensaje";
import MensajeChat from "./MensajeChat";

// ======================================================
// PROPS
// ======================================================

// Este componente recibirá una lista completa
// de mensajes desde Chat.tsx.

type ListaMensajesProps = {
  mensajes: Mensaje[];
};

// ======================================================
// COMPONENTE
// ======================================================

function ListaMensajes({ mensajes }: ListaMensajesProps) {
  return (
    <div>
      {mensajes.map((mensaje) => (
        <MensajeChat key={mensaje.id} mensaje={mensaje} />
      ))}
    </div>
  );
}

export default ListaMensajes;
