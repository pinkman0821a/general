import { useState } from "react";
import type { Mensaje } from "../types/Mensaje";
import ListaMensajes from "./ListaMensajes";
import EntradaMensaje from "./EntradaMensaje";
import UsoIa from "./UsoIa";
import { enviarMensajeAlServidorStream } from "../services/chatService";
import { limpiarRespuestaNova } from "../services/limpiarRespuestaNova";
import "../styles/Chat.css";

function Chat() {
  const [mensajes, setMensajes] = useState<Mensaje[]>([
    {
      id: 1,
      autor: "nova",
      texto: "Hola, soy NOVA. ¿En qué puedo ayudarte?",
    },
  ]);

  const [novaPensando, setNovaPensando] = useState(false);

  const [actualizacionUso, setActualizacionUso] = useState(0);

  async function enviarMensaje(texto: string) {
    const nuevoMensaje: Mensaje = {
      id: Date.now(),
      autor: "usuario",
      texto,
    };

    const mensajesConUsuario = [...mensajes, nuevoMensaje];

    setMensajes(mensajesConUsuario);
    setNovaPensando(true);

    const idRespuestaNova = Date.now() + 1;

    try {
      await enviarMensajeAlServidorStream(mensajesConUsuario, (fragmento) => {
        setNovaPensando(false);

        setMensajes((mensajesActuales) => {
          const respuestaExiste = mensajesActuales.some(
            (mensaje) => mensaje.id === idRespuestaNova,
          );

          if (!respuestaExiste) {
            return [
              ...mensajesActuales,
              {
                id: idRespuestaNova,
                autor: "nova",
                texto: limpiarRespuestaNova(fragmento),
              },
            ];
          }

          return mensajesActuales.map((mensaje) => {
            if (mensaje.id !== idRespuestaNova) {
              return mensaje;
            }

            return {
              ...mensaje,
              texto: limpiarRespuestaNova(mensaje.texto + fragmento),
            };
          });
        });
      });
    } catch (error) {
      console.error("[NOVA] Error al responder:", error);

      setMensajes((mensajesActuales) => [
        ...mensajesActuales,
        {
          id: Date.now(),
          autor: "nova",
          texto:
            "Tuve un problema al generar la respuesta. Inténtalo nuevamente.",
        },
      ]);
    } finally {
      setNovaPensando(false);

      setActualizacionUso((valor) => valor + 1);
    }
  }

  return (
    <section className="chat">
      <UsoIa actualizacion={actualizacionUso} />

      <h2>Chat con NOVA</h2>

      <ListaMensajes mensajes={mensajes} />

      {novaPensando && <p>NOVA está pensando...</p>}

      <EntradaMensaje onEnviar={enviarMensaje} />
    </section>
  );
}

export default Chat;
